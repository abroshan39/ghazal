Windows 8.1 Enterprise with Update (x64) - DVD (English)
en_windows_8.1_enterprise_with_update_x64_dvd_6054382.iso
SHA1: b7dd748446d89b9449a160cdc24bd282989bbd96

gcc (i686-posix-dwarf-rev0, Built by MinGW-W64 project) 5.4.0
cmake version 3.20.5
QMake version 3.0
Using Qt version 5.7.1 in C:/Qt/Qt5.7.1/5.7/mingw53_32/lib

zlib-1.2.11
quazip-1.3
