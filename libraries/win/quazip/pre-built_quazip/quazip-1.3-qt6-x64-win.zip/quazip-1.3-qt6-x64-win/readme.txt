Windows 10 (business editions), version 21H2 (updated Dec 2021) (x64) � DVD (English)
en-us_windows_10_business_editions_version_21h2_updated_dec_2021_x64_dvd_3da14f24.iso
SHA256: ff901df584f116c8b00d3fad42bdee15aef3e204ba882fa95fb745a35096a679

gcc (x86_64-posix-seh-rev3, Built by MinGW-W64 project) 11.2.0
cmake version 3.20.5
QMake version 3.1
Using Qt version 6.2.4 in C:/Qt/6.2.4/mingw_64/lib

zlib-1.2.11
quazip-1.3
