Debian GNU/Linux 8.10 (jessie) x86-64
debian-8.10.0-amd64-DVD-1.iso
SHA256: 44a282d899acf439e853685baba9534935ec16dc8749ba7800d3b0f556e4ab21

Kernel Name: Linux
kernel Release: 3.16.0-4-amd64
kernel Version: #1 SMP Debian 3.16.51-2 (2017-12-03)

Debian GLIBC 2.19-18+deb8u10
GNU C Library (Debian GLIBC 2.19-18+deb8u10) stable release version 2.19, by Roland McGrath et al.
Copyright (C) 2014 Free Software Foundation, Inc.
Compiled by GNU CC version 4.8.4.
Compiled on a Linux 3.16.43 system on 2017-06-18.

gcc (Debian 4.9.2-10) 4.9.2
Copyright (C) 2014 Free Software Foundation, Inc.

cmake version 3.20.5
QMake version 3.0
Using Qt version 5.7.1 in /opt/Qt5.7.1/5.7/gcc_64/lib

zlib-1.2.11
quazip-1.3
